# Private Item Share v0.3.1 — Foundry V11

Right-click a permitted item and use:
- Send Art Privately — choose another user to whisper the art only.
- Send Art to Chat — post the art to everyone immediately.

Click any image sent by this module in chat to open an enlarged Foundry image viewer.
No item name, item card, description, stats or inventory transfer is sent.

Install with https://raw.githubusercontent.com/Daikaze/Private-Message/main/v11/module.json
